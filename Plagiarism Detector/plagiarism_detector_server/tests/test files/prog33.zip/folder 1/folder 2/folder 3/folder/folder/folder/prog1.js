if(true) {
	
}
	
function myFunction(p1, p2) {
  return p1 + p2;   // The function returns the product of p1 and p2
}